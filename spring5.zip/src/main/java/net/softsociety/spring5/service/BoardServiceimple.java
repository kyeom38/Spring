package net.softsociety.spring5.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import net.softsociety.spring5.dao.BoardDAO;
import net.softsociety.spring5.domain.Board;

@Transactional //항상 세트로 실행이되도록 . 
@Slf4j
@Service
public class BoardServiceimple implements BoardService 
{
	@Autowired
	BoardDAO dao;
	
	@Override
	public int write(Board b) 
	{
		int n = dao.write(b);
		return n;
	}

	@Override
	public ArrayList<Board> blist() 
	{
		ArrayList<Board> b =dao.blist();
		return b;
	}

	@Override
	public Board read(int boardnum) 
	{
		//조회수 1증가 
		int n = dao.uphits(boardnum);
		Board b = dao.read(boardnum);
		
		return b;
	}

	@Override
	public int update(Board b) 
	{
		int n = dao.update(b);
		return n;
	}

	@Override
	public int delete(Board b) 
	{
		int n = dao.delete(b);
		return n;
	}


}
