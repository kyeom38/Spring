package net.softsociety.spring5.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import net.softsociety.spring5.domain.Board;

@Mapper
public interface BoardDAO 
{

	public int write(Board b);

	public Board selectM(String userInfo);

	public ArrayList<Board> blist();

	public Board read(int boardnum);

	int uphits(int boardnum);

	public int update(Board b);

	public int delete(Board b);

}
