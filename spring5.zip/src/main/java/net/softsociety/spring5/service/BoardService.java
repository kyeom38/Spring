package net.softsociety.spring5.service;

import java.util.ArrayList;

import net.softsociety.spring5.domain.Board;

public interface BoardService 
{

	public int write(Board b);

	public ArrayList<Board> blist();

	public Board read(int boardnum);

	public int delete(Board b);

	public int update(Board b);

}
